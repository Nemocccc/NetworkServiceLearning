import pygame
import random
import sys

# 初始化pygame
pygame.init()

# 设置屏幕大小
SCREEN_WIDTH = 200
SCREEN_HEIGHT = 200
SCOREBOARD_HEIGHT = 50  # 得分栏高度
BLOCK_SIZE = 20  # 每个方格的大小
ROWS = SCREEN_HEIGHT // BLOCK_SIZE
COLS = SCREEN_WIDTH // BLOCK_SIZE

# 定义颜色
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)
YELLOW = (255, 255, 0)  # 新增黄色用于食物

# 创建屏幕
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT + SCOREBOARD_HEIGHT))  # 屏幕高度增加得分栏高度
pygame.display.set_caption("Snake Game")

# 蛇类
class Snake:
    def __init__(self):
        self.body = [(COLS // 2, ROWS // 2)]  # 初始位置
        self.direction = None  # 初始方向向下

    def move(self):
        if self.direction is None:
            return
        head_x, head_y = self.body[0]
        dx, dy = self.direction
        new_head = ((head_x + dx) % COLS, (head_y + dy) % ROWS)
        self.body.insert(0, new_head)
        self.body.pop()

    def grow(self):
        head_x, head_y = self.body[0]
        dx, dy = self.direction
        new_head = ((head_x + dx) % COLS, (head_y + dy) % ROWS)
        self.body.insert(0, new_head)

    def change_direction(self, new_direction):
        if self.direction is None:
            self.direction = new_direction 
        elif (new_direction[0] == -self.direction[0] or new_direction[1] == -self.direction[1]):
            return  # 不能直接反向
        self.direction = new_direction

    def check_collision(self):
        head = self.body[0]
        if head in self.body[1:]:
            return True  # 撞到自己
        return False

# 食物类
class Food:
    def __init__(self, snake_body):
        self.position = [self.random_position(snake_body)]

    def random_position(self, snake_body):
        while True:
            position = (random.randint(0, COLS - 1), random.randint(0, ROWS - 1))
            if position not in snake_body:  # 确保食物不会出现在蛇身上
                return position

    def draw(self):
        for position in self.position:
            x, y = position
            pygame.draw.rect(screen, YELLOW, (x * BLOCK_SIZE, y * BLOCK_SIZE + SCOREBOARD_HEIGHT, BLOCK_SIZE, BLOCK_SIZE))  # 食物为黄色，位置向下偏移得分栏高度

# 游戏主函数
def main():
    clock = pygame.time.Clock()
    snake = Snake()
    food = Food(snake.body)  # 初始化食物时传入蛇的身体位置
    score = 0  # 初始化得分为-1

    # 设置字体
    font = pygame.font.Font(None, 48)  # 使用默认字体，大小为36

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_UP:
                    snake.change_direction((0, -1))
                elif event.key == pygame.K_DOWN:
                    snake.change_direction((0, 1))
                elif event.key == pygame.K_LEFT:
                    snake.change_direction((-1, 0))
                elif event.key == pygame.K_RIGHT:
                    snake.change_direction((1, 0))

        snake.move()

        # 检查是否吃到食物
        if snake.body[0] in food.position:
            snake.grow()
            food = Food(snake.body)  # 重新生成食物
            score += 1  # 吃到食物后得分加1

        # 检查碰撞
        if snake.check_collision():
            score="q"

        # 绘制游戏界面
        screen.fill(BLACK)

        # 绘制得分栏
        score_text = font.render(f"{score}", True, WHITE)  # 创建得分文本
        screen.blit(score_text, (5, 5))  # 将得分文本绘制到屏幕顶部

        # 绘制游戏区域的边框
        pygame.draw.rect(screen, WHITE, (0, SCOREBOARD_HEIGHT, SCREEN_WIDTH, SCREEN_HEIGHT), 1)

        # 绘制蛇头和蛇身体
        head_x, head_y = snake.body[0]
        pygame.draw.rect(screen, RED, (head_x * BLOCK_SIZE, head_y * BLOCK_SIZE + SCOREBOARD_HEIGHT, BLOCK_SIZE, BLOCK_SIZE))  # 蛇头为红色，位置向下偏移得分栏高度
        for x, y in snake.body[1:]:  # 蛇身体为绿色，位置向下偏移得分栏高度
            pygame.draw.rect(screen, GREEN, (x * BLOCK_SIZE, y * BLOCK_SIZE + SCOREBOARD_HEIGHT, BLOCK_SIZE, BLOCK_SIZE))

        food.draw()

        # 绘制方格
        for x in range(0, SCREEN_WIDTH, BLOCK_SIZE):
            pygame.draw.line(screen, WHITE, (x, SCOREBOARD_HEIGHT), (x, SCREEN_HEIGHT + SCOREBOARD_HEIGHT))
        for y in range(0, SCREEN_HEIGHT, BLOCK_SIZE):
            pygame.draw.line(screen, WHITE, (0, y + SCOREBOARD_HEIGHT), (SCREEN_WIDTH, y + SCOREBOARD_HEIGHT))

        pygame.display.flip()
        clock.tick(5)  # 控制游戏速度
    
            # 检查碰撞
        if snake.check_collision():
            game_over()  # 调用游戏结束函数


def game_over():


    # 等待用户按下任意键
    waiting = True
    while waiting:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                waiting = False

    pygame.quit()
    sys.exit()

if __name__ == "__main__":
    main()