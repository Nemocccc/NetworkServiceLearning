import random
import zmq
import threading
import json
import signal
import sys

# 蛇类
class Snake:
    def __init__(self):
        self.body = [(5, 5)]  # 初始位置
        self.direction = (0, 1)  # 初始方向向下

    def move(self):
        head_x, head_y = self.body[0]
        dx, dy = self.direction
        new_head = ((head_x + dx) % 10, (head_y + dy) % 10)
        self.body.insert(0, new_head)
        self.body.pop()

    def grow(self):
        head_x, head_y = self.body[0]
        dx, dy = self.direction
        new_head = ((head_x + dx) % 10, (head_y + dy) % 10)
        self.body.insert(0, new_head)

    def change_direction(self, new_direction):
        if (new_direction[0] == -self.direction[0] or new_direction[1] == -self.direction[1]):
            return  # 不能直接反向
        self.direction = new_direction

    def check_collision(self):
        head = self.body[0]
        if head in self.body[1:]:
            return True  # 撞到自己
        return False

# 食物类
class Food:
    def __init__(self, snake_body):
        self.position = [self.random_position(snake_body)]

    def random_position(self, snake_body):
        while True:
            position = (random.randint(0, 9), random.randint(0, 9))
            if position not in snake_body:
                return position

# 游戏逻辑
class GameService:
    def __init__(self):
        self.snake = Snake()
        self.food = Food(self.snake.body)
        self.running = True

    def move_snake(self):
        self.snake.move()
        if self.snake.body[0] in self.food.position:
            self.snake.grow()
            self.food = Food(self.snake.body)
        if self.snake.check_collision():
            self.running = False
        return self.get_game_state()

    def change_direction(self, direction):
        self.snake.change_direction(direction)
        return self.get_game_state()

    def get_game_state(self):
        return {
            "snake_body": self.snake.body,
            "food_position": self.food.position,
            "running": self.running
        }

class GameServer:
    def __init__(self, port):
        self.context = zmq.Context()
        self.socket = self.context.socket(zmq.REP)
        self.socket.bind(f"tcp://*:{port}")
        self.games = {}  # 存储每个客户端的游戏实例
        self.lock = threading.Lock()  # 添加线程锁
        self.running = True  # 添加运行标志

    def _get_game(self, client_id):
        """根据客户端ID获取或创建游戏实例"""
        with self.lock:
            if client_id not in self.games:
                self.games[client_id] = GameService()
            return self.games[client_id]

    def handle_request(self):
        while self.running:  # 使用运行标志控制循环
            try:
                message = self.socket.recv_string(flags=zmq.NOBLOCK)  # 非阻塞接收
                request = json.loads(message)
                client_id = request["client_id"]
                action = request["action"]
                params = request.get("params", [])

                response = {}
                try:
                    game = self._get_game(client_id)
                    if action == "move_snake":
                        response = game.move_snake()
                    elif action == "change_direction":
                        direction = params[0]
                        response = game.change_direction(direction)
                    elif action == "get_game_state":
                        response = game.get_game_state()
                    else:
                        response = {"error": "Invalid action"}
                except Exception as e:
                    response = {"error": str(e)}

                self.socket.send_string(json.dumps(response))
            except zmq.Again:
                pass  # 如果没有消息，跳过

    def stop(self):
        self.running = False  # 设置运行标志为 False
        self.socket.close()  # 关闭套接字
        self.context.term()  # 终止 ZeroMQ 上下文

def signal_handler(signal, frame):
    print("\nStopping server...")
    server.stop()
    sys.exit(0)

def main():
    port = 4242
    global server
    server = GameServer(port)
    print(f"Server is running on tcp://0.0.0.0:{port}")

    # 注册信号处理函数
    signal.signal(signal.SIGINT, signal_handler)

    server.handle_request()

if __name__ == "__main__":
    main()