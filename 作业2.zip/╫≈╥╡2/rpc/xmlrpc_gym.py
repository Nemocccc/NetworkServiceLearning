import pygame
import numpy as np
import random
import time
import xmlrpc.client
import uuid
import gymnasium as gym
import sys

class Snake(gym.Env):
    metadata = {'render.modes': ['human']}
    def __init__(self, server_address="http://127.0.0.1:4242",render_mode='human'):
        self.server_address = server_address
        self.client_id = self.generate_unique_id()
        self.c = xmlrpc.client.ServerProxy(server_address)
        self.observation_space = gym.spaces.Box(low=0, high=3, shape=(100,), dtype=np.uint8)
        self.action_space = gym.spaces.Discrete(4)
        self.snake_len = 0

        self.screen=None
        self.render_mode = render_mode

    def generate_unique_id(self):
        return str(uuid.uuid4())

    def move_snake(self):
        return self.c.move_snake(self.client_id)

    def change_direction(self, direction):
        return self.c.change_direction(self.client_id, direction)

    def get_game_state(self):
        return self.c.get_game_state(self.client_id)

    def reset(self, seed=0):
        info = {}
        sim_info = self.get_game_state()
        snake_body = sim_info['snake_body']
        food_position = sim_info['food_position']

        obs = np.zeros((10, 10), dtype=np.uint8)
        for x, y in snake_body:
            obs[x][y] = 1
        for x, y in food_position:
            obs[x][y] = 2
        obs = obs.flatten()
        self.snake_len = len(snake_body)
        return obs, info

    def step(self, action):
        direction_handler = [(0, -1), (-1, 0), (0, 1), (1, 0)]
        direction = direction_handler[action]
        self.change_direction(direction)
        self.move_snake()
        sim_info = self.get_game_state()
        info = {}
        snake_body = sim_info['snake_body']
        food_position = sim_info['food_position']

        obs = np.zeros((10, 10), dtype=np.uint8)
        for x, y in snake_body:
            obs[x][y] = 1
        for x, y in food_position:
            obs[x][y] = 2
        obs = obs.flatten()
        running = sim_info['running']
        truncated = False
        terminated = not running
        reward = len(snake_body) - self.snake_len
        self.snake_len = len(snake_body)
        return obs, reward, terminated, truncated, info

    def render(self):
        if self.render_mode != 'human':
            raise ValueError(f"Unsupported render mode: {self.render_mode}")

        if self.screen is None:
            # Pygame initialization
            pygame.init()
            self.screen_width = 200
            self.screen_height = 200
            self.scoreboard_height = 50  # Scoreboard height
            self.block_size = 20  # Size of each block
            self.rows = self.screen_height // self.block_size
            self.cols = self.screen_width // self.block_size

            self.white = (255, 255, 255)
            self.black = (0, 0, 0)
            self.red = (255, 0, 0)
            self.green = (0, 255, 0)
            self.yellow = (255, 255, 0)

            self.screen = pygame.display.set_mode((self.screen_width, self.screen_height + self.scoreboard_height))
            pygame.display.set_caption("Snake Game")


        sim_info = self.get_game_state()
        snake_body = sim_info['snake_body']

        food_position = sim_info['food_position']
        running = sim_info['running']

        # Clear screen
        self.screen.fill(self.black)

        # Draw scoreboard
        font = pygame.font.Font(None, 36)
        score_text = font.render(f"Score: {self.snake_len - 1}", True, self.white)
        self.screen.blit(score_text, (5, 5))

        # Draw game area border
        pygame.draw.rect(self.screen, self.white, (0, self.scoreboard_height, self.screen_width, self.screen_height), 1)

        # Draw snake
        for x, y in snake_body[:1]:
            pygame.draw.rect(self.screen, self.red, (x * self.block_size, y * self.block_size + self.scoreboard_height, self.block_size, self.block_size))


        # Draw snake
        for x, y in snake_body[1:]:
            pygame.draw.rect(self.screen, self.green, (x * self.block_size, y * self.block_size + self.scoreboard_height, self.block_size, self.block_size))

        # Draw food
        for x, y in food_position:
            pygame.draw.rect(self.screen, self.yellow, (x * self.block_size, y * self.block_size + self.scoreboard_height, self.block_size, self.block_size))

        # Draw grid lines
        for x in range(0, self.screen_width, self.block_size):
            pygame.draw.line(self.screen, self.white, (x, self.scoreboard_height), (x, self.screen_height + self.scoreboard_height))
        for y in range(0, self.screen_height, self.block_size):
            pygame.draw.line(self.screen, self.white, (0, y + self.scoreboard_height), (self.screen_width, y + self.scoreboard_height))

        # Update display
        pygame.display.flip()

        # Check for game over
        if not running:
            print("Game Over!")
            time.sleep(2)  # Wait for 2 seconds before closing
            pygame.quit()
            sys.exit()

if __name__ == "__main__":
    env = Snake()

    obs, info = env.reset()

    done = False

    while not done:

        action = env.action_space.sample()
        obs, reward, terminated, truncated, info = env.step(action)
        env.render()
        done = terminated or truncated
        time.sleep(0.1)