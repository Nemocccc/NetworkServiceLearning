import random
import zerorpc
from threading import Lock

# 蛇类
class Snake:
    def __init__(self):
        self.body = [(5, 5)]  # 初始位置
        self.direction = (0, 1)  # 初始方向向下

    def move(self):
        head_x, head_y = self.body[0]
        dx, dy = self.direction
        new_head = ((head_x + dx) % 10, (head_y + dy) % 10)
        self.body.insert(0, new_head)
        self.body.pop()

    def grow(self):
        head_x, head_y = self.body[0]
        dx, dy = self.direction
        new_head = ((head_x + dx) % 10, (head_y + dy) % 10)
        self.body.insert(0, new_head)

    def change_direction(self, new_direction):
        if (new_direction[0] == -self.direction[0] or new_direction[1] == -self.direction[1]):
            return  # 不能直接反向
        self.direction = new_direction

    def check_collision(self):
        head = self.body[0]
        if head in self.body[1:]:
            return True  # 撞到自己
        return False

# 食物类
class Food:
    def __init__(self, snake_body):
        self.position = [self.random_position(snake_body)]

    def random_position(self, snake_body):
        while True:
            position = (random.randint(0, 9), random.randint(0, 9))
            if position not in snake_body:
                return position

# 游戏逻辑
class GameService:
    def __init__(self):
        self.snake = Snake()
        self.food = Food(self.snake.body)
        self.running = True

    def move_snake(self):
        self.snake.move()
        if self.snake.body[0] in self.food.position:
            self.snake.grow()
            self.food = Food(self.snake.body)
        if self.snake.check_collision():
            self.running = False
        return self.get_game_state()

    def change_direction(self, direction):
        self.snake.change_direction(direction)
        return self.get_game_state()

    def get_game_state(self):
        return {
            "snake_body": self.snake.body,
            "food_position": self.food.position,
            "running": self.running
        }

class GameRPC:
    def __init__(self):
        self.games = {}  # 存储每个客户端的游戏实例
        self.lock = Lock()  # 添加线程锁

    def _get_game(self, client_id):
        """根据客户端ID获取或创建游戏实例"""
        with self.lock:
            if client_id not in self.games:
                self.games[client_id] = GameService()
            return self.games[client_id]

    def move_snake(self, client_id):
        game = self._get_game(client_id)
        return game.move_snake()

    def change_direction(self, client_id, direction):
        game = self._get_game(client_id)
        return game.change_direction(direction)

    def get_game_state(self, client_id):
        game = self._get_game(client_id)
        return game.get_game_state()

def main():
    server = zerorpc.Server(GameRPC())
    server.bind("tcp://0.0.0.0:4242")
    print("Server is running on tcp://0.0.0.0:4242")
    server.run()

if __name__ == "__main__":
    main()