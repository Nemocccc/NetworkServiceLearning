import zerorpc
import uuid
import multiprocessing

class Client:
    def __init__(self, server_address):
        self.server_address = server_address
        self.client_id = self.generate_unique_id()
        self.c = zerorpc.Client()
        self.c.connect(server_address)

    def generate_unique_id(self):
        return str(uuid.uuid4())

    def move_snake(self):
        return self.c.move_snake(self.client_id)

    def change_direction(self, direction):
        return self.c.change_direction(self.client_id, direction)

    def get_game_state(self):
        return self.c.get_game_state(self.client_id)

def run_client(server_address, client_id):
    client = Client(server_address)
    client.client_id = client_id
    print(f"Client {client.client_id} connected to the server.")
    print(f"Client {client.client_id}", client.get_game_state())
    print(f"Client {client.client_id}", client.change_direction((0, 1)))
    print(f"Client {client.client_id}", client.move_snake())
    print(f"Client {client.client_id}", client.get_game_state())

def main():
    server_address = "tcp://127.0.0.1:4242"
    num_clients = 3

    clients = [Client(server_address) for _ in range(num_clients)]

    processes = []
    for client in clients:
        process = multiprocessing.Process(target=run_client, args=(server_address, client.client_id))
        processes.append(process)
        process.start()

    for process in processes:
        process.join()

    print("All clients have finished their operations.")

if __name__ == "__main__":
    main()