
# 快速开始

启动xmlrpc_server.py，该server可以是其他语言编写的，这里为了快速验证，依然采用python

启动xmlrpc_gym.py

即可观测到跨进程的rpc调用像本地调用一样

# 可以学习的东西

rpc编程思路，在其他语言中通过rpc协议，完成这种操作。