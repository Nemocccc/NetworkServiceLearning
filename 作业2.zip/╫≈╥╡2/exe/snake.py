import queue
import subprocess
import time
import os
import cv2
import psutil
import win32gui
import win32con
import pyautogui
import multiprocessing
import gymnasium as gym
from PIL import ImageGrab
from PIL import Image, ImageFilter
import numpy as np
import rapidocr_onnxruntime as rapidocr

def split_image(img):
    # 打开图像
    width, height = img.size
    # 这里假设得分栏占图像高度的 1/5（可根据实际情况调整）
    score_height = height // 5
    # 切分得分栏
    score_area = (0, 0, width, score_height)
    score_img = img.crop(score_area)
    # 切分游戏界面栏
    game_area = (0, score_height, width, height)
    game_img = img.crop(game_area)
    return score_img, game_img

class ScreenshotProcess(multiprocessing.Process):
    def __init__(self, hwnd_queue, screenshot_queue, stop_event):
        super().__init__()
        self.hwnd_queue = hwnd_queue
        self.screenshot_queue = screenshot_queue
        self.stop_event = stop_event
        self.hwnd = None

    def run(self):
        while not self.stop_event.is_set():
            if self.hwnd is None and not self.hwnd_queue.empty():
                self.hwnd = self.hwnd_queue.get()
            
            if self.hwnd:
                try:
                    window_rect = win32gui.GetWindowRect(self.hwnd)
                    left, top, right, bottom = window_rect
                    width = right - left
                    height = bottom - top

                    client_rect = win32gui.GetClientRect(self.hwnd)
                    client_width = client_rect[2] - client_rect[0]
                    client_height = client_rect[3] - client_rect[1]

                    border_width = (width - client_width) // 2
                    title_bar_height = height - client_height - border_width

                    client_left = left + border_width
                    client_top = top + title_bar_height
                    client_right = client_left + client_width
                    client_bottom = client_top + client_height

                    img_list=[]
                    for i in range(10):
                        img = ImageGrab.grab(bbox=(client_left, client_top, client_right, client_bottom))
                        time.sleep(0.01)  # 等待0.01秒，避免截图过快
                        img_list.append(img)
                        img_np = np.array(img)
                        cv2.imshow("Screenshot", cv2.cvtColor(img_np, cv2.COLOR_RGB2BGR))
                        cv2.waitKey(1)  # 动态展示这张图片，刷新窗口
                        

                    # img = ImageGrab.grab(bbox=(client_left, client_top, client_right, client_bottom))

                    # img_np = np.array(img)
                    # cv2.imshow("Screenshot", cv2.cvtColor(img_np, cv2.COLOR_RGB2BGR))
                    # cv2.waitKey(1)  # 动态展示这张图片，刷新窗口
                    # 在窗口中更新显示截图
                    while not self.screenshot_queue.empty():
                        try:
                            self.screenshot_queue.get(timeout=0.1)
                        except queue.Empty:
                            print("队列已空")
                            break
                        # print(f"[OCR进程] 截图队列大小: {self.screenshot_queue.qsize()}")
            
                    if img:
                        self.screenshot_queue.put(img_list)
                        # print(f"[截图进程] 截图成功, 当前分数: {self.screenshot_queue.qsize()}")
                except Exception as e:
                    print(f"[截图进程错误] {e}")
            
            time.sleep(0.01)  # 控制截图频率

class OCRProcess(multiprocessing.Process):
    def __init__(self, screenshot_queue, score_queue, stop_event):
        super().__init__()
        self.screenshot_queue = screenshot_queue
        self.score_queue = score_queue
        self.stop_event = stop_event
        self.reader = None  # 将在子进程中初始化

    def extract_score(self, score_img):
        if self.reader is None:
            self.reader = rapidocr.RapidOCR()
        
        # 将 PIL 图像对象转换为 NumPy 数组
        score_img_np = np.array(score_img)
        # 进行 OCR 识别
        result, _ = self.reader(score_img_np)
        
        score = ""
        if result:
            line=result[0]
            text = line[1]  # RapidOCR 返回的结果格式为 [(bbox, text), ...]
            digits_and_sign = ''.join(filter(lambda x: x.isdigit() or x == 'q', text))
            score += digits_and_sign
        
        try:
            if score=='q':
                return -1
            return int(score) if score else 0
        except ValueError:
            return 0  # 如果无法转换为整数，返回 0

    def run(self):
        while not self.stop_event.is_set():
            latest_img = None
            # 非阻塞式获取所有可用截图，只保留最后一张
            latest_img_list= self.screenshot_queue.get() 
            while not self.screenshot_queue.empty():
                latest_img_list = self.screenshot_queue.get()
                print(f"[OCR进程] 截图队列大小: {self.screenshot_queue.qsize()}")
            
            if latest_img_list is not None:  # 确保有有效截图
                try:
                    game_state_list = []
                    for img in latest_img_list:
                        score_img, game_img = split_image(img)
                        game_img = game_img.resize((64, 64), Image.Resampling.LANCZOS)
                        game_state = np.array(game_img)
                        game_state_list.append(game_state)

                    current_score = self.extract_score(score_img)
                    while not self.score_queue.empty():
                        current_score,game_state_list = self.score_queue.get()
                    self.score_queue.put((current_score, game_state_list))
                    print(f"[OCR进程] 分数: {current_score}")
                except Exception as e:
                    print(f"[OCR进程错误] {e}")
            
            # time.sleep(0.01)  # 更短的休眠提高响应速度
            
class SnakeGameExe(gym.Env):
    def __init__(self, exe_path="./exe/snake.exe"):
        super(SnakeGameExe, self).__init__()
        self.exe_path = exe_path
        self.process = None
        self.pid = None
        self.hwnd = None
        self.base_title = "Snake Game"
        self.score = 0
        
        # 多进程相关
        self.stop_event = multiprocessing.Event()
        self.hwnd_queue = multiprocessing.Queue()
        self.screenshot_queue = multiprocessing.Queue()
        self.score_queue = multiprocessing.Queue()
        
        self.screenshot_process = ScreenshotProcess(self.hwnd_queue, self.screenshot_queue, self.stop_event)
        self.ocr_process = OCRProcess(self.screenshot_queue, self.score_queue, self.stop_event)
        
        self.steps_without_score = 0
        self.max_steps_without_score = 1000  # 如果50步分数没变化，认为游戏结束

        self.screenshot_count = 0
        self.screenshot_dir = "screenshots"
        self.action_space = gym.spaces.Discrete(4)  # 上、下、左、右
        self.observation_space = gym.spaces.Box(low=0, high=255, shape=(64, 64, 3), dtype=np.uint8)  # 假设图像大小为64x64，RGB三通道

    def start_game(self):
        """启动游戏并找到窗口"""
        if self.process is None or self.process.poll() is not None:
            self.process = subprocess.Popen(self.exe_path)
            time.sleep(3)  # 等待游戏启动
            
        # 查找游戏窗口
        for _ in range(10):  # 尝试10次
            if self.find_window():
                break
            time.sleep(0.5)
        else:
            raise RuntimeError("无法找到游戏窗口")
        
        self.activate_window()
        time.sleep(0.5)  # 确保窗口激活
        
        # 启动截图和OCR进程
        self.stop_event.clear()
        self.hwnd_queue.put(self.hwnd)
        self.screenshot_process.start()
        self.ocr_process.start()
        time.sleep(3)  # 等待进程启动

    def get_game_state(self):
        """获取当前游戏状态"""
        game_state = None
        current_score = self.score
        game_over = False
        
        # 获取最新的分数
        current_score,game_state_list = self.score_queue.get()

        for game_state in game_state_list:
            img_np = np.array(game_state)
            cv2.imshow("Screenshot_small", cv2.cvtColor(img_np, cv2.COLOR_RGB2BGR))
            cv2.waitKey(1)  # 动态展示这张图片，刷新窗口
            # 在窗口中更新显示截图
        game_state=np.concatenate(game_state_list, axis=0)

        # while not self.score_queue.empty():
        #     current_score,game_state = self.score_queue.get()
        #     print(f"[主进程] 当前分数: {current_score},screenshot队列大小: {self.score_queue.qsize()}")

        # 判断游戏是否结束
        if current_score == -1:
            game_over = True
            current_score = self.last_score
            self.close()
        elif current_score == self.last_score:
            self.steps_without_score += 1
            if self.steps_without_score >= self.max_steps_without_score:
                game_over = True
                self.close()
        else:
            self.steps_without_score = 0
            self.last_score = current_score
        
        return game_state, current_score, game_over

    def reset(self, seed=None):
        """重置游戏环境"""
        self.close()  # 先关闭现有游戏
        
        self.start_game()
        self.score = 0
        self.last_score = 0
        self.steps_without_score = 0
        
        # 清空队列
        while not self.screenshot_queue.empty():
            self.screenshot_queue.get()
        while not self.score_queue.empty():
            self.score_queue.get()
        
        game_state, current_score, _ = self.get_game_state()
        if game_state is None:
            raise RuntimeError("无法获取初始游戏状态")
            
        self.score = current_score
        return game_state, {}

    def step(self, action):
        """执行一个动作"""
        actions = ['up', 'down', 'left', 'right']
        if action < 0 or action >= len(actions):
            action = 0
            
        self.send_key(actions[action])
        time.sleep(0.1)  # 等待游戏响应
        
        game_state, current_score, game_over = self.get_game_state()
        if game_state is None:
            return np.zeros((64, 64, 3)), 0, True, True, {}
        
        reward = current_score - self.score
        self.score = current_score
        
        # 打印当前状态
        print(f"动作: {actions[action]}, 分数: {self.score}, 奖励: {reward}, 结束: {game_over}")
        
        return game_state, reward, game_over, False, {}

    def find_window(self):
        def callback(hwnd, hwnd_list):
            if win32gui.IsWindow(hwnd) and win32gui.IsWindowVisible(hwnd):
                title = win32gui.GetWindowText(hwnd)
                if self.base_title in title:
                    hwnd_list.append(hwnd)
        hwnd_list = []
        win32gui.EnumWindows(callback, hwnd_list)
        if hwnd_list:
            self.hwnd = hwnd_list[0]
            return True
        return False

    def activate_window(self):
        if self.hwnd:
            try:
                win32gui.SetForegroundWindow(self.hwnd)
            except Exception as e:
                print(f"[错误] 激活窗口失败: {e}")

    def send_key(self, key):
        if self.hwnd:
            try:
                self.activate_window()
                key_code = {
                    'up': win32con.VK_UP,
                    'down': win32con.VK_DOWN,
                    'left': win32con.VK_LEFT,
                    'right': win32con.VK_RIGHT
                }.get(key.lower(), 0)
                if key_code:
                    win32gui.PostMessage(self.hwnd, win32con.WM_KEYDOWN, key_code, 0)
                    win32gui.PostMessage(self.hwnd, win32con.WM_KEYUP, key_code, 0)
            except Exception as e:
                print(f"[错误] 发送按键失败: {e}")

    def send_quit_event(self):
        """发送pygame.quit事件关闭窗口"""
        if self.hwnd:
            try:
                self.activate_window()
                win32gui.PostMessage(self.hwnd, win32con.WM_CLOSE, 0, 0)
                time.sleep(1)  # 等待窗口关闭
                return True
            except Exception as e:
                print(f"发送退出事件失败: {e}")
        return False

    def close(self):
        """关闭游戏窗口"""
        # 停止子进程
        self.stop_event.set()
        if self.ocr_process.is_alive():
            print("正在关闭OCR进程...")
            self.ocr_process.join(timeout=1)
            self.ocr_process.terminate()
            print("OCR进程已关闭")
        
        if self.screenshot_process.is_alive():
            print("正在关闭截图进程...")
            self.screenshot_process.join(timeout=1)
            self.screenshot_process.terminate()
            print("截图进程已关闭")

        
        if self.hwnd:
            print("正在关闭游戏窗口...")
            self.send_quit_event()
            print("游戏窗口已关闭")
            time.sleep(1)  # 等待窗口关闭
        
        if self.process and self.process.poll() is None:
            try:
                print("正在终止游戏进程...")
                self.process.terminate()
                self.process.wait(timeout=2)
                print("游戏进程已终止")
            except:
                pass
        
        self.hwnd = None
        self.process = None

if __name__ == "__main__":
    # 确保在Windows上使用spawn方法
    multiprocessing.freeze_support()
    multiprocessing.set_start_method('spawn')
    
    env = SnakeGameExe()
    obs, info = env.reset() 
    done = False
    while not done:
        action = env.action_space.sample()  # 随机选择一个动作
        obs, reward, done, truncated, info = env.step(action)
        print(f"reward:{reward},done:{done},truncated:{truncated},info:{info}")
    env.close()
    print("游戏已关闭")