import subprocess
import time
import os
import cv2
import psutil
import win32gui
import win32con
import pyautogui
import multiprocessing
import gymnasium as gym
from PIL import ImageGrab
from PIL import Image, ImageFilter
import numpy as np
import rapidocr_onnxruntime as rapidocr

def split_image(img):
    # 打开图像
    width, height = img.size
    # 这里假设得分栏占图像高度的 1/5（可根据实际情况调整）
    score_height = height // 5
    # 切分得分栏
    score_area = (0, 0, width, score_height)
    score_img = img.crop(score_area)
    # 切分游戏界面栏
    game_area = (0, score_height, width, height)
    game_img = img.crop(game_area)
    return score_img, game_img




class SnakeGameExe(gym.Env):
    def __init__(self, exe_path="./exe/snake.exe"):
        super(SnakeGameExe, self).__init__()
        self.exe_path = exe_path
        self.process = None
        self.pid = None
        self.hwnd = None
        self.base_title = "Snake Game"
        self.score=0
        self.reader = rapidocr.RapidOCR()
        
        self.steps_without_score = 0
        self.max_steps_without_score = 1000  # 如果50步分数没变化，认为游戏结束

        self.screenshot_count = 0
        self.screenshot_dir = "screenshots"
        self.action_space = gym.spaces.Discrete(4)  # 上、下、左、右
        self.observation_space = gym.spaces.Box(low=0, high=255, shape=(64, 64, 3), dtype=np.uint8)  # 假设图像大小为64x64，RGB三通道

    def extract_score(self, score_img):
        
        # 将 PIL 图像对象转换为 NumPy 数组
        score_img_np = np.array(score_img)
        # 进行 OCR 识别
        result, _ = self.reader(score_img_np)
        
        score = ""
        if result:
            line=result[0]
            text = line[1]  # RapidOCR 返回的结果格式为 [(bbox, text), ...]
            digits_and_sign = ''.join(filter(lambda x: x.isdigit() or x == 'q', text))
            score += digits_and_sign
        
        try:
            if score=='q':
                return -1
            return int(score) if score else 0
        except ValueError:
            return 0  # 如果无法转换为整数，返回 0
    
    def start_game(self):
        """启动游戏并找到窗口"""
        if self.process is None or self.process.poll() is not None:
            self.process = subprocess.Popen(self.exe_path)
            time.sleep(3)  # 等待游戏启动
            
        # 查找游戏窗口
        for _ in range(10):  # 尝试10次
            if self.find_window():
                break
            time.sleep(0.5)
        else:
            raise RuntimeError("无法找到游戏窗口")
        
        self.activate_window()
        time.sleep(0.5)  # 确保窗口激活




    def get_game_state(self):
        """获取当前游戏状态"""
        img = self.take_screenshot()
        if img is None:
            return None, 0, False
        
        score_img, game_img = split_image(img)
        
        # 处理游戏画面
        game_img = game_img.resize((64, 64), Image.Resampling.LANCZOS)
        game_state = np.array(game_img)
        if len(game_state.shape) == 2:
            game_state = np.stack([game_state]*3, axis=-1)
        
        # 提取分数
        current_score = self.extract_score(score_img)
        
        # 判断游戏是否结束
        game_over = False
        if current_score == -1:
            game_over = True
            current_score = self.last_score
            self.close()

        elif current_score == self.last_score:
            self.steps_without_score += 1
            if self.steps_without_score >= self.max_steps_without_score:
                game_over = True
                self.close()
                

        else:
            self.steps_without_score = 0
            self.last_score = current_score
        
        return game_state, current_score, game_over

    def reset(self, seed=None):
        """重置游戏环境"""
        self.close()  # 先关闭现有游戏
        
        self.start_game()
        self.score = 0
        self.last_score = 0
        self.steps_without_score = 0
        
        game_state, current_score, _ = self.get_game_state()
        if game_state is None:
            raise RuntimeError("无法获取初始游戏状态")
            
        self.score = current_score
        return game_state, {}

    def step(self, action):
        """执行一个动作"""
        actions = ['up', 'down', 'left', 'right']
        if action < 0 or action >= len(actions):
            action = 0
            
        self.send_key(actions[action])
        time.sleep(0.1)  # 等待游戏响应
        
        game_state, current_score, game_over = self.get_game_state()
        if game_state is None:
            return np.zeros((64, 64, 3)), 0, True, True, {}
        
        reward = current_score - self.score
        self.score = current_score
        
        # 打印当前状态
        print(f"动作: {actions[action]}, 分数: {self.score}, 奖励: {reward}, 结束: {game_over}")
        
        return game_state, reward, game_over, False, {}

    def take_screenshot(self):
        if self.hwnd:
            window_rect = win32gui.GetWindowRect(self.hwnd)
            left, top, right, bottom = window_rect
            width = right - left
            height = bottom - top

            client_rect = win32gui.GetClientRect(self.hwnd)
            client_width = client_rect[2] - client_rect[0]
            client_height = client_rect[3] - client_rect[1]

            border_width = (width - client_width) // 2
            title_bar_height = height - client_height - border_width

            client_left = left + border_width
            client_top = top + title_bar_height
            client_right = client_left + client_width
            client_bottom = client_top + client_height

            img = ImageGrab.grab(bbox=(client_left, client_top, client_right, client_bottom))

            screenshot_path = os.path.join(self.screenshot_dir, f"screenshot_{self.screenshot_count}.png")
            self.screenshot_count += 1
            img = ImageGrab.grab(bbox=(client_left, client_top, client_right, client_bottom))
            # img.save(screenshot_path)
            img_np = np.array(img)
            cv2.imshow("Screenshot", cv2.cvtColor(img_np, cv2.COLOR_RGB2BGR))
            cv2.waitKey(1)  # 动态展示这张图片，刷新窗口
            return img


    def find_window(self):
        def callback(hwnd, hwnd_list):
            if win32gui.IsWindow(hwnd) and win32gui.IsWindowVisible(hwnd):
                title = win32gui.GetWindowText(hwnd)
                if self.base_title in title:
                    hwnd_list.append(hwnd)
        hwnd_list = []
        win32gui.EnumWindows(callback, hwnd_list)
        if hwnd_list:
            self.hwnd = hwnd_list[0]
            return True
        return False

    def activate_window(self):
        if self.hwnd:
            try:
                win32gui.SetForegroundWindow(self.hwnd)
            except Exception as e:
                print(f"[错误] 激活窗口失败: {e}")


    def send_key(self, key):
        if self.hwnd:
            try:
                self.activate_window()
                # time.sleep(0.1)
                key_code = {
                    'up': win32con.VK_UP,
                    'down': win32con.VK_DOWN,
                    'left': win32con.VK_LEFT,
                    'right': win32con.VK_RIGHT
                }.get(key.lower(), 0)
                if key_code:
                    win32gui.PostMessage(self.hwnd, win32con.WM_KEYDOWN, key_code, 0)
                    win32gui.PostMessage(self.hwnd, win32con.WM_KEYUP, key_code, 0)
            except Exception as e:
                print(f"[错误] 发送按键失败: {e}")

    def send_quit_event(self):
        """发送pygame.quit事件关闭窗口"""
        if self.hwnd:
            try:
                self.activate_window()
                # 发送退出事件
                win32gui.PostMessage(self.hwnd, win32con.WM_CLOSE, 0, 0)
                time.sleep(1)  # 等待窗口关闭
                return True
            except Exception as e:
                print(f"发送退出事件失败: {e}")
        return False

    def close(self):
        """关闭游戏窗口"""
        if self.hwnd:
            self.send_quit_event()
            time.sleep(1)  # 等待窗口关闭
        
        if self.process and self.process.poll() is None:
            # 如果窗口关闭失败，再尝试终止进程
            try:
                self.process.terminate()
                self.process.wait(timeout=2)
            except:
                pass
        
        self.hwnd = None
        self.process = None


if __name__ == "__main__":
    pass
    env=SnakeGameExe()
    
    obs,info=env.reset() 
    done = False
    while not done:
        action = env.action_space.sample()  # 随机选择一个动作
        obs, reward, done, truncated, info = env.step(action)
        print(f"reward:{reward},done:{done},truncated:{truncated},info:{info}")